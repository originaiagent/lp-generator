import streamlit as st
from modules.data_store import DataStore
from modules.file_parser import FileParser
from modules.image_analyzer import ImageAnalyzer
from modules.ai_provider import AIProvider
from modules.prompt_manager import PromptManager
from modules.settings_manager import SettingsManager
import os
from pathlib import Path

def render_input_page():
    '''入力情報ページのメイン関数'''
    st.title('📥 入力情報')
    
    data_store = DataStore()
    
    # 現在の製品IDを取得
    if 'current_product_id' not in st.session_state:
        st.error("製品IDが設定されていません。")
        return
    
    product_id = st.session_state['current_product_id']
    
    # 各セクションをレンダリング
    render_product_images_upload(data_store, product_id)
    render_competitor_urls_input(data_store, product_id)
    render_sheets_upload(data_store, product_id)
    render_reference_images_upload(data_store, product_id)

def render_product_images_upload(data_store, product_id):
    '''製品画像アップロード'''
    st.subheader("製品画像")
    
    uploaded_files = st.file_uploader(
        "製品画像をアップロードしてください",
        type=['png', 'jpg', 'jpeg'],
        accept_multiple_files=True,
        key="product_images"
    )
    
    if uploaded_files:
        upload_dir = Path(f"data/uploads/{product_id}/product_images")
        upload_dir.mkdir(parents=True, exist_ok=True)
        
        image_paths = []
        for uploaded_file in uploaded_files:
            file_path = upload_dir / uploaded_file.name
            with open(file_path, "wb") as f:
                f.write(uploaded_file.getbuffer())
            image_paths.append(str(file_path))
            st.success(f"アップロード完了: {uploaded_file.name}")
        
        # データを更新
        product = data_store.get_product(product_id)
        if not product:
            product = {}
        product['product_images'] = image_paths
        data_store.update_product(product_id, product)

def render_competitor_urls_input(data_store, product_id):
    '''競合URL入力'''
    st.subheader("競合URL")
    
    competitor_urls = st.text_area(
        "競合URLを入力してください（1行1URL）",
        height=150,
        key="competitor_urls"
    )
    
    if competitor_urls:
        urls = [url.strip() for url in competitor_urls.split('\n') if url.strip()]
        
        # データを更新
        product = data_store.get_product(product_id)
        if not product:
            product = {}
        product['competitor_urls'] = urls
        data_store.update_product(product_id, product)

def render_sheets_upload(data_store, product_id):
    '''各種シートアップロード'''
    st.subheader("データシート")
    
    col1, col2 = st.columns(2)
    
    with col1:
        product_sheet = st.file_uploader(
            "製品情報シート",
            type=['xlsx', 'csv'],
            key="product_sheet"
        )
        
        if product_sheet:
            upload_dir = Path(f"data/uploads/{product_id}/sheets")
            upload_dir.mkdir(parents=True, exist_ok=True)
            
            file_path = upload_dir / f"product_sheet_{product_sheet.name}"
            with open(file_path, "wb") as f:
                f.write(product_sheet.getbuffer())
            
            # ファイルを解析
            file_parser = FileParser()
            try:
                parsed_data = file_parser.parse_file(str(file_path))
                
                # データを更新
                product = data_store.get_product(product_id)
                if not product:
                    product = {}
                product['product_sheet'] = str(file_path)
                product['product_sheet_data'] = parsed_data
                data_store.update_product(product_id, product)
                
                st.success("製品情報シートをアップロードしました")
            except Exception as e:
                st.error(f"ファイル解析エラー: {e}")
    
    with col2:
        review_sheet = st.file_uploader(
            "競合レビューシート",
            type=['xlsx', 'csv'],
            key="review_sheet"
        )
        
        if review_sheet:
            upload_dir = Path(f"data/uploads/{product_id}/sheets")
            upload_dir.mkdir(parents=True, exist_ok=True)
            
            file_path = upload_dir / f"review_sheet_{review_sheet.name}"
            with open(file_path, "wb") as f:
                f.write(review_sheet.getbuffer())
            
            # ファイルを解析
            file_parser = FileParser()
            try:
                parsed_data = file_parser.parse_file(str(file_path))
                
                # データを更新
                product = data_store.get_product(product_id)
                if not product:
                    product = {}
                product['review_sheet'] = str(file_path)
                product['review_sheet_data'] = parsed_data
                data_store.update_product(product_id, product)
                
                st.success("競合レビューシートをアップロードしました")
            except Exception as e:
                st.error(f"ファイル解析エラー: {e}")

def render_reference_images_upload(data_store, product_id):
    '''参考画像アップロード'''
    st.subheader("参考画像")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**参考LP画像**")
        lp_images = st.file_uploader(
            "参考LP画像をアップロードしてください",
            type=['png', 'jpg', 'jpeg'],
            accept_multiple_files=True,
            key="lp_images"
        )
        
        if lp_images:
            upload_dir = Path(f"data/uploads/{product_id}/reference_lp")
            upload_dir.mkdir(parents=True, exist_ok=True)
            
            image_paths = []
            for uploaded_file in lp_images:
                file_path = upload_dir / uploaded_file.name
                with open(file_path, "wb") as f:
                    f.write(uploaded_file.getbuffer())
                image_paths.append(str(file_path))
                st.success(f"アップロード完了: {uploaded_file.name}")
            
            # データを更新
            product = data_store.get_product(product_id)
            if not product:
                product = {}
            product['reference_lp_images'] = image_paths
            data_store.update_product(product_id, product)
    
    with col2:
        st.write("**トンマナ参考画像**")
        tone_images = st.file_uploader(
            "トンマナ参考画像をアップロードしてください",
            type=['png', 'jpg', 'jpeg'],
            accept_multiple_files=True,
            key="tone_images"
        )
        
        if tone_images:
            upload_dir = Path(f"data/uploads/{product_id}/tone_manner")
            upload_dir.mkdir(parents=True, exist_ok=True)
            
            image_paths = []
            for uploaded_file in tone_images:
                file_path = upload_dir / uploaded_file.name
                with open(file_path, "wb") as f:
                    f.write(uploaded_file.getbuffer())
                image_paths.append(str(file_path))
                st.success(f"アップロード完了: {uploaded_file.name}")
            
            # データを更新
            product = data_store.get_product(product_id)
            if not product:
                product = {}
            product['tone_manner_images'] = image_paths
            data_store.update_product(product_id, product)
    
    # 参考画像分析ボタン
    if st.button('参考画像から構成を分析'):
        product = data_store.get_product(product_id)
        if product and 'reference_lp_images' in product:
            settings_manager = SettingsManager()

            settings = settings_manager.get_settings()

            ai_provider = AIProvider(settings)

            prompt_manager = PromptManager()

            image_analyzer = ImageAnalyzer(ai_provider, prompt_manager)
            analyze_reference_images(image_analyzer, product['reference_lp_images'], product_id, data_store)
        else:
            st.warning("参考LP画像がアップロードされていません")

def analyze_reference_images(image_analyzer, image_paths, product_id, data_store):
    '''参考画像から構成を分析'''
    with st.spinner('参考画像を分析中...'):
        try:
            analysis_results = []
            for image_path in image_paths:
                if os.path.exists(image_path):
                    result = image_analyzer.analyze_image(image_path)
                    analysis_results.append(result)
            
            if analysis_results:
                # 分析結果を統合して構成情報を生成
                structure_data = {
                    'analysis_results': analysis_results,
                    'analyzed_at': st.session_state.get('timestamp', ''),
                    'image_count': len(analysis_results)
                }
                
                # データを更新
                product = data_store.get_product(product_id)
                if not product:
                    product = {}
                product['structure'] = structure_data
                data_store.update_product(product_id, product)
                
                st.success(f"{len(analysis_results)}件の画像を分析しました")
            else:
                st.error("画像の分析に失敗しました")
                
        except Exception as e:
            st.error(f"分析エラー: {e}")

render_input_page()