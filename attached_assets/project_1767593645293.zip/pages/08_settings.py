import streamlit as st
import json
import os
from modules.settings_manager import SettingsManager

MODELS_FILE = "data/models.json"

DOCS_LINKS = {
    "anthropic": "https://docs.anthropic.com/en/docs/about-claude/models",
    "openai": "https://platform.openai.com/docs/models",
    "gemini": "https://ai.google.dev/gemini-api/docs/models/gemini",
}

PRICING_LINKS = {
    "anthropic": "https://www.anthropic.com/pricing",
    "openai": "https://openai.com/api/pricing/",
    "gemini": "https://ai.google.dev/pricing",
}

def load_models():
    if os.path.exists(MODELS_FILE):
        with open(MODELS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"llm": {}, "image": {}}

def render_settings_page():
    st.title('⚙️ 設定')
    
    settings_manager = SettingsManager()
    settings = settings_manager.get_settings()
    models_config = load_models()
    
    # モデル更新ボタン（上部に配置）
    col1, col2 = st.columns([3, 1])
    with col2:
        if st.button('🔄 モデル一覧を更新', key='refresh_models'):
            refresh_models()
    
    tab1, tab2, tab3 = st.tabs(["🤖 LLM設定", "🖼️ 画像生成", "🔑 APIキー"])
    
    with tab1:
        render_llm_settings(settings_manager, settings, models_config)
    
    with tab2:
        render_image_settings(settings_manager, settings, models_config)
    
    with tab3:
        render_api_key_status()

def refresh_models():
    """APIからモデル一覧を取得して更新"""
    with st.spinner('最新モデル一覧を取得中...'):
        try:
            from modules.model_fetcher import ModelFetcher
            fetcher = ModelFetcher()
            models = fetcher.fetch_and_save()
            
            llm_count = sum(len(v) for v in models.get("llm", {}).values())
            image_count = sum(len(v) for v in models.get("image", {}).values())
            
            st.success(f'✅ 更新完了！ LLM: {llm_count}モデル, 画像: {image_count}モデル')
            st.rerun()
        except Exception as e:
            st.error(f'更新エラー: {str(e)}')

def render_llm_settings(settings_manager, settings, models_config):
    st.subheader("LLM設定")
    
    providers = ["anthropic", "openai", "gemini"]
    provider_names = {
        "anthropic": "Anthropic (Claude)",
        "openai": "OpenAI (GPT)",
        "gemini": "Google (Gemini)"
    }
    
    current_provider = settings.get("llm_provider", "anthropic")
    if current_provider not in providers:
        current_provider = "anthropic"
    
    provider = st.selectbox(
        "プロバイダ",
        providers,
        index=providers.index(current_provider),
        format_func=lambda x: provider_names.get(x, x),
        key="llm_provider_select"
    )
    
    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"[📖 モデル一覧]({DOCS_LINKS.get(provider, '#')})")
    with col2:
        st.markdown(f"[💰 料金表]({PRICING_LINKS.get(provider, '#')})")
    
    llm_models = models_config.get("llm", {}).get(provider, [])
    model_ids = [m["id"] for m in llm_models]
    model_names = {m["id"]: f"{m['name']} - {m['desc']}" for m in llm_models}
    
    current_model = settings.get("llm_model", "")
    
    use_custom = st.checkbox("カスタムモデルを使用", key="llm_custom_check", 
                             value=current_model not in model_ids and current_model != "")
    
    if use_custom:
        model = st.text_input(
            "モデルID（直接入力）",
            value=current_model,
            placeholder="例: claude-3-5-sonnet-20241022",
            key="llm_model_custom"
        )
        st.caption("↑ 上のリンクから最新モデルIDを確認できます")
    else:
        if not model_ids:
            st.warning("モデル一覧がありません。「モデル一覧を更新」ボタンを押してください。")
            model = ""
        else:
            if current_model in model_ids:
                default_idx = model_ids.index(current_model)
            else:
                default_idx = 0
            
            model = st.selectbox(
                "モデル",
                model_ids,
                index=default_idx,
                format_func=lambda x: model_names.get(x, x),
                key="llm_model_select"
            )
    
    if st.button("LLM設定を保存", key="save_llm", type="primary"):
        settings["llm_provider"] = provider
        settings["llm_model"] = model
        settings_manager.update_settings(settings)
        st.success("保存しました")
    
    st.markdown("---")
    st.caption(f"現在: {settings.get('llm_provider', 'なし')} / {settings.get('llm_model', 'なし')}")

def render_image_settings(settings_manager, settings, models_config):
    st.subheader("画像生成AI設定")
    
    providers = ["auto", "openai", "gemini"]
    provider_names = {
        "auto": "自動選択",
        "openai": "OpenAI (DALL-E)",
        "gemini": "Google (Imagen)"
    }
    
    current_provider = settings.get("image_provider", "auto")
    if current_provider not in providers:
        current_provider = "auto"
    
    image_provider = st.selectbox(
        "プロバイダ",
        providers,
        index=providers.index(current_provider),
        format_func=lambda x: provider_names.get(x, x),
        key="image_provider_select"
    )
    
    if image_provider != "auto":
        col1, col2 = st.columns(2)
        with col1:
            st.markdown(f"[📖 モデル一覧]({DOCS_LINKS.get(image_provider, '#')})")
        with col2:
            st.markdown(f"[💰 料金表]({PRICING_LINKS.get(image_provider, '#')})")
    
    image_model = None
    
    if image_provider != "auto":
        image_models = models_config.get("image", {}).get(image_provider, [])
        model_ids = [m["id"] for m in image_models]
        model_names = {m["id"]: f"{m['name']} - {m['desc']}" for m in image_models}
        
        current_model = settings.get("image_model", "")
        
        use_custom = st.checkbox("カスタムモデルを使用", key="image_custom_check",
                                 value=current_model not in model_ids and current_model != "")
        
        if use_custom:
            image_model = st.text_input(
                "モデルID（直接入力）",
                value=current_model,
                placeholder="例: nano-banana-pro-preview",
                key="image_model_custom"
            )
            st.caption("↑ 上のリンクから最新モデルIDを確認できます")
        else:
            if not model_ids:
                st.warning("モデル一覧がありません。「モデル一覧を更新」ボタンを押してください。")
                image_model = ""
            else:
                if current_model in model_ids:
                    default_idx = model_ids.index(current_model)
                else:
                    default_idx = 0
                
                image_model = st.selectbox(
                    "モデル",
                    model_ids,
                    index=default_idx,
                    format_func=lambda x: model_names.get(x, x),
                    key="image_model_select"
                )
    else:
        st.info("利用可能なAPIを自動で選択します")
    
    from modules.image_generator import ImageGenerator
    current_gen = ImageGenerator(image_provider)
    st.write(f"**現在使用中:** {current_gen.get_provider_name()}")
    
    if st.button("画像生成設定を保存", key="save_image", type="primary"):
        settings["image_provider"] = image_provider
        if image_model:
            settings["image_model"] = image_model
        settings_manager.update_settings(settings)
        st.success("保存しました")
    
    st.markdown("---")
    st.caption(f"現在: {settings.get('image_provider', 'auto')} / {settings.get('image_model', '自動')}")
    
    with st.expander("💰 画像生成コスト目安"):
        st.markdown("""
        | モデル | 1枚あたり |
        |--------|-----------|
        | DALL-E 3 | $0.04〜0.08 |
        | Imagen 4.0 | 従量課金 |
        | Nano Banana Pro | 従量課金 |
        """)

def render_api_key_status():
    st.subheader("APIキー状態")
    
    keys = {
        "OpenAI (GPT, DALL-E)": os.environ.get('OPENAI_API_KEY'),
        "Anthropic (Claude)": os.environ.get('ANTHROPIC_API_KEY'),
        "Google (Gemini, Imagen)": os.environ.get('GOOGLE_API_KEY')
    }
    
    for name, key in keys.items():
        if key:
            st.success(f"✅ {name}: 設定済み")
        else:
            st.warning(f"⚠️ {name}: 未設定")
    
    st.markdown("---")
    st.info("APIキーはReplitのSecretsで設定してください")
    
    with st.expander("💰 LLMコスト目安 (1Mトークンあたり)"):
        st.markdown("""
        | モデル | 入力 | 出力 |
        |--------|------|------|
        | Claude 3.5 Sonnet | $3 | $15 |
        | GPT-4o | $2.5 | $10 |
        | GPT-4o mini | $0.15 | $0.6 |
        | Gemini 1.5 Flash | $0.075 | $0.3 |
        """)

render_settings_page()
