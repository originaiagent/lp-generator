import streamlit as st
from modules.prompt_manager import PromptManager

def render_prompt_page():
    '''プロンプト管理ページのメイン関数'''
    st.title('💬 プロンプト管理')
    
    prompt_manager = PromptManager()
    
    # プロンプト選択
    prompt_id = render_prompt_selector(prompt_manager)
    
    if prompt_id:
        # プロンプト編集
        render_prompt_editor(prompt_manager, prompt_id)

def render_prompt_selector(prompt_manager):
    '''プロンプト選択'''
    prompts = prompt_manager.list_prompts()
    prompt_options = {f"{p['name']} ({p['id']})": p['id'] for p in prompts}
    
    selected = st.selectbox(
        "編集するプロンプトを選択してください",
        options=list(prompt_options.keys()),
        key="prompt_selector"
    )
    
    return prompt_options.get(selected) if selected else None

def render_prompt_editor(prompt_manager, prompt_id):
    '''プロンプト編集'''
    prompt_data = prompt_manager.get_prompt(prompt_id)
    
    if prompt_data:
        st.subheader("プロンプトテンプレート")
        
        # 変数一覧表示
        if 'variables' in prompt_data and prompt_data['variables']:
            st.info(f"利用可能な変数: {', '.join(['{' + var + '}' for var in prompt_data['variables']])}")
        
        # テンプレート編集
        template = st.text_area(
            "テンプレート",
            value=prompt_data.get('template', ''),
            height=200,
            key=f"template_{prompt_id}"
        )
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button('保存', type="primary"):
                save_prompt(prompt_manager, prompt_id, template)
        
        with col2:
            if st.button('デフォルトに戻す'):
                reset_prompt(prompt_manager, prompt_id)

def save_prompt(prompt_manager, prompt_id, template):
    '''プロンプト保存'''
    try:
        with st.spinner('保存中...'):
            prompt_manager.update_prompt(prompt_id, template)
            st.success('プロンプトが保存されました！')
            st.rerun()
    except Exception as e:
        st.error(f'保存エラー: {str(e)}')

def reset_prompt(prompt_manager, prompt_id):
    '''デフォルトに戻す'''
    try:
        with st.spinner('リセット中...'):
            prompt_manager.reset_to_default(prompt_id)
            st.success('デフォルトに戻しました！')
            st.rerun()
    except Exception as e:
        st.error(f'リセットエラー: {str(e)}')

render_prompt_page()