import streamlit as st
import os
import glob
import requests
import subprocess
import base64
import json
import re
from datetime import datetime

st.set_page_config(page_title="開発用 AI Chat", page_icon="🤖", layout="wide")

HISTORY_FILE = "data/chat_history.json"
MEMORY_FILE = "data/ai_memory.json"
MODELS_FILE = "data/models.json"

# ==================== データ管理 ====================

def load_json(filepath, default):
    try:
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
    except:
        pass
    return default

def save_json(filepath, data):
    try:
        os.makedirs(os.path.dirname(filepath) or '.', exist_ok=True)
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        st.error(f"保存エラー: {e}")

def load_history(): return load_json(HISTORY_FILE, [])
def save_history(m): save_json(HISTORY_FILE, m)
def load_memory(): return load_json(MEMORY_FILE, [])
def save_memory(m): save_json(MEMORY_FILE, m)
def load_models(): return load_json(MODELS_FILE, {"llm": {}, "image": {}})

def get_llm_settings():
    try:
        from modules.settings_manager import SettingsManager
        s = SettingsManager().get_settings()
        return {"provider": s.get("llm_provider", "anthropic"), "model": s.get("llm_model", "claude-sonnet-4-20250514")}
    except:
        return {"provider": "anthropic", "model": "claude-sonnet-4-20250514"}

def save_llm_settings(provider, model):
    try:
        from modules.settings_manager import SettingsManager
        sm = SettingsManager()
        s = sm.get_settings()
        s["llm_provider"], s["llm_model"] = provider, model
        sm.update_settings(s)
        return True
    except:
        return False

def refresh_models():
    try:
        from modules.model_fetcher import ModelFetcher
        return ModelFetcher().fetch_and_save()
    except:
        return None

# ==================== ユーティリティ ====================

def log(area, msg):
    area.info(f"🔄 {msg}")

def run_bash(cmd, timeout=30):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout, cwd=os.getcwd())
        out = (r.stdout + r.stderr).strip()
        return out if out else "(出力なし)"
    except subprocess.TimeoutExpired:
        return "タイムアウト"
    except Exception as e:
        return f"エラー: {e}"

def get_project_structure():
    files = []
    for p in ["*.py", "pages/*.py", "modules/*.py", "data/*.json", ".streamlit/*"]:
        files.extend(glob.glob(p))
    return "\n".join(sorted(files))

def check_incomplete(response):
    patterns = [r'\.\.\.$', r'# 以下.*(同様|省略|既存)', r'# etc', r'以下、既存', r'# 以下略', r'\.\.\.\"', r'\.\.\.\'', r'\.\.\.\n```']
    return any(re.search(p, response, re.IGNORECASE | re.MULTILINE) for p in patterns)

def check_truncated(response):
    """途中で切れてないかチェック"""
    # コードブロックが閉じてない
    open_blocks = response.count('```python') + response.count('```json') + response.count('```toml') + response.count('```\n')
    close_blocks = response.count('\n```')
    if open_blocks > close_blocks:
        return True
    # ===FILE: があるのに ``` で終わってない
    if '===FILE:' in response and not response.rstrip().endswith('```'):
        return True
    return False

# ==================== LLM API ====================

def get_system_prompt(memory, user_goal):
    memory_text = "\n".join([f"• {m}" for m in memory]) if memory else "なし"
    structure = get_project_structure()
    
    return f"""あなたは熟練の開発者です。

【プロジェクト構造】
{structure}

【メモリ】
{memory_text}

【ユーザーの目標】
{user_goal}

=====================================================
行動原則
=====================================================

■ 絶対ルール
1. ファイルの中身は渡されていない → 自分で cat して読む
2. 推測で修正しない → 調査してから修正
3. 省略禁止 →「...」「以下同様」は使わない
4. 1回のレスポンスで1ファイルだけ修正 → 複数必要なら「残りN件」と伝える

■ 思考プロセス

STEP 1: 調査
===BASH===
cat filepath
ls -la
===END===

STEP 2: 分析
- 何が問題か
- どう直すか

STEP 3: 修正（1ファイルのみ、完全な内容）
===FILE: filepath===
```
完全なコード
```

===REMAINING===
残り修正ファイル: file1.py, file2.py
===END===

STEP 4: 検証方法
===VERIFY===
確認コマンド
===END===

■ 重要
- pages.tomlでサイドバー名を設定（page_titleはブラウザタブ用）
- 1ファイルが大きくても完全に出力すること
- 複数ファイル修正は1つずつ順番に

=====================================================
出力形式
=====================================================

===BASH===
調査コマンド
===END===

===FILE: filepath===
```
完全なコード（省略禁止）
```

===REMAINING===
残り: file1.py, file2.py（あれば）
===END===

===VERIFY===
検証コマンド
===END===

===MEMORY===
学んだこと
===END==="""

def call_llm(messages, system_prompt, provider, model, status):
    log(status, f"API呼び出し中...")
    recent = messages[-10:]
    
    if provider == "anthropic":
        return _call_anthropic(recent, system_prompt, model)
    elif provider == "openai":
        return _call_openai(recent, system_prompt, model)
    elif provider == "gemini":
        return _call_gemini(recent, system_prompt, model)
    return "不明なプロバイダ"

def _call_anthropic(msgs, sys, model):
    key = os.environ.get('ANTHROPIC_API_KEY')
    if not key:
        return "ANTHROPIC_API_KEY未設定"
    
    api_msgs = []
    for m in msgs:
        if m["role"] == "user":
            content = [{"type": "image", "source": {"type": "base64", "media_type": img.get("type", "image/png"), "data": img["data"]}} for img in m.get("images", [])]
            content.append({"type": "text", "text": m["content"]})
            api_msgs.append({"role": "user", "content": content})
        else:
            api_msgs.append({"role": "assistant", "content": m["content"]})
    
    try:
        r = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": key, "content-type": "application/json", "anthropic-version": "2023-06-01"},
            json={"model": model, "max_tokens": 8192, "system": sys, "messages": api_msgs},
            timeout=90
        )
        r.raise_for_status()
        return r.json()["content"][0]["text"]
    except Exception as e:
        return f"APIエラー: {e}"

def _call_openai(msgs, sys, model):
    key = os.environ.get('OPENAI_API_KEY')
    if not key:
        return "OPENAI_API_KEY未設定"
    
    api_msgs = [{"role": "system", "content": sys}]
    for m in msgs:
        if m["role"] == "user":
            content = [{"type": "image_url", "image_url": {"url": f"data:{img.get('type')};base64,{img['data']}"}} for img in m.get("images", [])]
            content.append({"type": "text", "text": m["content"]})
            api_msgs.append({"role": "user", "content": content})
        else:
            api_msgs.append({"role": "assistant", "content": m["content"]})
    
    try:
        r = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
            json={"model": model, "max_tokens": 8192, "messages": api_msgs},
            timeout=90
        )
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]
    except Exception as e:
        return f"APIエラー: {e}"

def _call_gemini(msgs, sys, model):
    key = os.environ.get('GOOGLE_API_KEY')
    if not key:
        return "GOOGLE_API_KEY未設定"
    
    contents = [{"role": "user", "parts": [{"text": sys}]}, {"role": "model", "parts": [{"text": "理解しました。"}]}]
    for m in msgs:
        parts = [{"inline_data": {"mime_type": img.get("type"), "data": img["data"]}} for img in m.get("images", [])]
        parts.append({"text": m["content"]})
        contents.append({"role": "user" if m["role"] == "user" else "model", "parts": parts})
    
    try:
        r = requests.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}",
            json={"contents": contents, "generationConfig": {"maxOutputTokens": 8192}},
            timeout=90
        )
        r.raise_for_status()
        return r.json()["candidates"][0]["content"]["parts"][0]["text"]
    except Exception as e:
        return f"APIエラー: {e}"

def parse_response(response):
    result = {"files": {}, "memory": [], "bash": [], "verify": [], "remaining": []}
    
    for m in re.findall(r'===FILE:\s*([^\n=]+)===\s*```[^\n]*\n(.*?)```', response, re.DOTALL):
        result["files"][m[0].strip()] = m[1].strip()
    
    m = re.search(r'===BASH===\s*(.+?)===END===', response, re.DOTALL)
    if m:
        result["bash"] = [c.strip() for c in m.group(1).strip().split('\n') if c.strip() and not c.startswith('#')]
    
    m = re.search(r'===VERIFY===\s*(.+?)===END===', response, re.DOTALL)
    if m:
        result["verify"] = [c.strip() for c in m.group(1).strip().split('\n') if c.strip() and not c.startswith('#')]
    
    m = re.search(r'===REMAINING===\s*(.+?)===END===', response, re.DOTALL)
    if m:
        remaining_text = m.group(1).strip()
        # ファイル名を抽出
        files = re.findall(r'[\w/]+\.(?:py|json|toml|md)', remaining_text)
        result["remaining"] = files
    
    m = re.search(r'===MEMORY===\s*(.+?)(?:===|$)', response, re.DOTALL)
    if m:
        result["memory"] = [s.strip().lstrip('•-').strip() for s in m.group(1).strip().split('\n') if s.strip()]
    
    return result

def apply_files(files, status):
    log(status, "ファイル更新中...")
    updated = []
    for fp, content in files.items():
        try:
            if os.path.exists(fp):
                with open(fp, 'r') as f:
                    with open(fp + ".bak", 'w') as bf:
                        bf.write(f.read())
            d = os.path.dirname(fp)
            if d:
                os.makedirs(d, exist_ok=True)
            with open(fp, 'w', encoding='utf-8') as f:
                f.write(content)
            updated.append(fp)
        except Exception as e:
            st.error(f"失敗 {fp}: {e}")
    return updated

def process_conversation(user_input, images, memory, provider, model, status):
    system_prompt = get_system_prompt(memory, user_input)
    current_msgs = st.session_state.messages.copy()
    
    all_files = {}
    all_remaining = []
    
    max_loops = 10
    for i in range(max_loops):
        log(status, f"ステップ {i+1}/{max_loops}")
        
        response = call_llm(current_msgs, system_prompt, provider, model, status)
        
        if "APIエラー" in response:
            return response, {"files": all_files, "memory": [], "bash": [], "verify": [], "remaining": []}
        
        parsed = parse_response(response)
        
        # 途中切れチェック
        if check_truncated(response):
            log(status, "応答が途中で切れた→続きを要求")
            current_msgs.append({"role": "assistant", "content": response, "images": []})
            current_msgs.append({"role": "user", "content": "応答が途中で切れています。続きを出力してください。", "images": []})
            continue
        
        # 省略チェック
        if check_incomplete(response) and parsed["files"]:
            log(status, "省略検出→再要求")
            current_msgs.append({"role": "assistant", "content": response, "images": []})
            current_msgs.append({"role": "user", "content": "コードが省略されています。完全な内容を出力してください。", "images": []})
            continue
        
        # bashがあれば実行
        if parsed["bash"]:
            log(status, "調査実行中...")
            results = []
            for cmd in parsed["bash"][:5]:
                out = run_bash(cmd)
                results.append(f"$ {cmd}\n{out}")
            
            current_msgs.append({"role": "assistant", "content": response, "images": []})
            current_msgs.append({"role": "user", "content": f"調査結果:\n```\n{chr(10).join(results)}\n```\n修正を出力してください。", "images": []})
            continue
        
        # ファイルがあれば収集
        if parsed["files"]:
            all_files.update(parsed["files"])
            
            # 残りがあれば続行
            if parsed["remaining"]:
                log(status, f"残り {len(parsed['remaining'])}件を処理中...")
                current_msgs.append({"role": "assistant", "content": response, "images": []})
                current_msgs.append({"role": "user", "content": f"次のファイルを出力してください: {', '.join(parsed['remaining'])}", "images": []})
                continue
            
            # 完了
            log(status, f"修正完了（{len(all_files)}ファイル）")
            parsed["files"] = all_files
            return response, parsed
        
        # 何もなければ終了
        return response, parsed
    
    parsed["files"] = all_files
    return response, parsed

# ==================== UI ====================

if "messages" not in st.session_state:
    st.session_state.messages = load_history()
if "memory" not in st.session_state:
    st.session_state.memory = load_memory()
if "pending" not in st.session_state:
    st.session_state.pending = {"files": {}, "memory": [], "verify": [], "remaining": []}
if "images" not in st.session_state:
    st.session_state.images = []

settings = get_llm_settings()
models = load_models()

st.title("🤖 開発用 AI Chat")

col1, col2 = st.columns([3, 1])

with col1:
    chat_area = st.container(height=300)
    with chat_area:
        for msg in st.session_state.messages:
            with st.chat_message(msg["role"]):
                for img in msg.get("images", []):
                    st.image(f"data:{img['type']};base64,{img['data']}", width=100)
                st.markdown(msg["content"])
    
    status = st.empty()
    
    if st.session_state.pending["files"]:
        st.warning(f"📝 {len(st.session_state.pending['files'])}件の修正")
        
        with st.expander("内容", expanded=True):
            for fp, content in st.session_state.pending["files"].items():
                st.write(f"**{fp}** ({len(content)}文字)")
                st.code(content[:2000] + ("\n... (表示省略)" if len(content) > 2000 else ""))
        
        c1, c2 = st.columns(2)
        if c1.button("✅ 適用 & 検証", type="primary", use_container_width=True):
            updated = apply_files(st.session_state.pending["files"], status)
            st.success(f"更新: {', '.join(updated)}")
            
            if st.session_state.pending["verify"]:
                log(status, "検証中...")
                for cmd in st.session_state.pending["verify"]:
                    st.code(f"$ {cmd}\n{run_bash(cmd)}")
            
            log(status, "デバッグ中...")
            debug = run_bash("python auto_debugger_full.py", 120)
            if "失敗" in debug or "Error" in debug:
                st.error("❌ エラー")
                st.code(debug)
            else:
                st.success("✅ OK")
            
            status.empty()
            st.session_state.pending = {"files": {}, "memory": [], "verify": [], "remaining": []}
            st.rerun()
        
        if c2.button("❌ キャンセル", use_container_width=True):
            st.session_state.pending = {"files": {}, "memory": [], "verify": [], "remaining": []}
            st.rerun()
    
    if st.session_state.pending["memory"]:
        st.info("💡 学び")
        for mem in st.session_state.pending["memory"]:
            c1, c2 = st.columns([4, 1])
            c1.write(f"• {mem}")
            if c2.button("追加", key=f"m_{hash(mem)}"):
                st.session_state.memory.append(mem)
                save_memory(st.session_state.memory)
                st.session_state.pending["memory"].remove(mem)
                st.rerun()
    
    uploaded = st.file_uploader("📷", type=["png", "jpg", "jpeg"], accept_multiple_files=True, label_visibility="collapsed")
    if uploaded:
        st.session_state.images = [{"data": base64.b64encode(f.read()).decode(), "type": f.type} for f in uploaded]
    
    if prompt := st.chat_input("指示を入力..."):
        msg = {"role": "user", "content": prompt, "images": st.session_state.images.copy(), "timestamp": datetime.now().isoformat()}
        st.session_state.messages.append(msg)
        st.session_state.images = []
        
        response, parsed = process_conversation(prompt, msg["images"], st.session_state.memory, settings["provider"], settings["model"], status)
        
        st.session_state.pending = {"files": parsed["files"], "memory": parsed["memory"], "verify": parsed["verify"], "remaining": parsed.get("remaining", [])}
        st.session_state.messages.append({"role": "assistant", "content": response, "timestamp": datetime.now().isoformat()})
        save_history(st.session_state.messages)
        status.empty()
        st.rerun()

with col2:
    st.subheader("🔧 設定")
    
    if st.button("🔄 モデル更新", use_container_width=True):
        if refresh_models():
            st.success("✅")
            st.rerun()
    
    providers = ["anthropic", "openai", "gemini"]
    provider = st.selectbox("プロバイダ", providers, index=providers.index(settings["provider"]) if settings["provider"] in providers else 0,
                            format_func=lambda x: {"anthropic": "Claude", "openai": "GPT", "gemini": "Gemini"}[x])
    
    model_list = models.get("llm", {}).get(provider, [])
    model_ids = [m["id"] for m in model_list]
    model_names = {m["id"]: m["name"] for m in model_list}
    
    if model_ids:
        idx = model_ids.index(settings["model"]) if settings["model"] in model_ids else 0
        model = st.selectbox("モデル", model_ids, index=idx, format_func=lambda x: model_names.get(x, x))
    else:
        model = st.text_input("モデルID", settings["model"])
    
    if st.button("保存", use_container_width=True):
        save_llm_settings(provider, model)
        st.success("✅")
        st.rerun()
    
    st.markdown("---")
    st.subheader("📝 メモリ")
    
    for i, mem in enumerate(st.session_state.memory):
        c1, c2 = st.columns([5, 1])
        c1.caption(mem)
        if c2.button("🗑", key=f"d_{i}"):
            st.session_state.memory.pop(i)
            save_memory(st.session_state.memory)
            st.rerun()
    
    with st.expander("➕"):
        new = st.text_input("追加", key="new_mem")
        if st.button("追加", key="add") and new:
            st.session_state.memory.append(new)
            save_memory(st.session_state.memory)
            st.rerun()
    
    st.markdown("---")
    st.caption(f"履歴: {len(st.session_state.messages)}件")
    if st.button("🗑 クリア", use_container_width=True):
        st.session_state.messages = []
        st.session_state.pending = {"files": {}, "memory": [], "verify": [], "remaining": []}
        if os.path.exists(HISTORY_FILE):
            os.remove(HISTORY_FILE)
        st.rerun()
