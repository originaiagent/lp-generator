import streamlit as st
from modules.data_store import DataStore
from modules.output_generator import OutputGenerator
from modules.ai_provider import AIProvider
from modules.prompt_manager import PromptManager
from modules.settings_manager import SettingsManager

def render_output_page():
    '''出力ページのメイン関数'''
    st.title('📤 出力')
    
    # データストアとOutputGeneratorの初期化
    data_store = DataStore()
    settings_manager = SettingsManager()

    settings = settings_manager.get_settings()

    ai_provider = AIProvider(settings)
    prompt_manager = PromptManager()
    settings_manager = SettingsManager()
    
    output_generator = OutputGenerator(
        ai_provider=ai_provider,
        prompt_manager=prompt_manager
    )
    
    # 商品データの取得
    product_data = data_store.get_product_data()
    
    if not product_data:
        st.warning("商品データが入力されていません。まず商品情報を入力してください。")
        return
    
    # 画像プロンプトセクション
    render_image_prompts_section(output_generator, product_data)
    
    st.divider()
    
    # 指示書セクション
    render_design_instruction_section(output_generator, product_data)

def render_image_prompts_section(output_generator, product_data):
    '''画像プロンプトセクション'''
    st.subheader("🎨 画像プロンプト生成")
    
    col1, col2 = st.columns([1, 3])
    
    with col1:
        if st.button('画像プロンプト生成'):
            generate_image_prompts(output_generator, product_data)
    
    with col2:
        if 'generated_image_prompts' in st.session_state and st.session_state.generated_image_prompts:
            if st.download_button(
                label="プロンプトをダウンロード",
                data=st.session_state.generated_image_prompts,
                file_name="image_prompts.txt",
                mime="text/plain"
            ):
                st.success("プロンプトをダウンロードしました！")
    
    # 生成されたプロンプトの表示
    if 'generated_image_prompts' in st.session_state and st.session_state.generated_image_prompts:
        st.text_area(
            "生成されたプロンプト",
            value=st.session_state.generated_image_prompts,
            height=200,
            key="image_prompts_display"
        )

def render_design_instruction_section(output_generator, product_data):
    '''指示書セクション'''
    st.subheader("📋 指示書生成")
    
    col1, col2 = st.columns([1, 3])
    
    with col1:
        if st.button('指示書生成'):
            generate_design_instruction(output_generator, product_data)
    
    with col2:
        if 'generated_instruction' in st.session_state and st.session_state.generated_instruction:
            if st.download_button(
                label="指示書をダウンロード",
                data=st.session_state.generated_instruction,
                file_name="design_instruction.txt",
                mime="text/plain"
            ):
                st.success("指示書をダウンロードしました！")
    
    # 指示書プレビュー
    if 'generated_instruction' in st.session_state and st.session_state.generated_instruction:
        st.text_area(
            "指示書プレビュー",
            value=st.session_state.generated_instruction,
            height=300,
            key="instruction_preview"
        )

def generate_image_prompts(output_generator, product_data):
    '''画像プロンプト生成'''
    try:
        with st.spinner("画像プロンプトを生成中..."):
            prompts = output_generator.build_image_prompt(product_data)
            
            if isinstance(prompts, list):
                # リストの場合は改行で結合
                prompt_text = "\n\n".join([f"プロンプト {i+1}:\n{prompt}" for i, prompt in enumerate(prompts)])
            else:
                # 文字列の場合はそのまま
                prompt_text = str(prompts)
            
            st.session_state.generated_image_prompts = prompt_text
            st.success("画像プロンプトが生成されました！")
            st.rerun()
            
    except Exception as e:
        st.error(f"画像プロンプト生成中にエラーが発生しました: {str(e)}")

def generate_design_instruction(output_generator, product_data):
    '''指示書生成'''
    try:
        with st.spinner("指示書を生成中..."):
            instruction = output_generator.generate_design_instruction(product_data)
            st.session_state.generated_instruction = str(instruction)
            st.success("指示書が生成されました！")
            st.rerun()
            
    except Exception as e:
        st.error(f"指示書生成中にエラーが発生しました: {str(e)}")

# メイン関数の呼び出し
render_output_page()