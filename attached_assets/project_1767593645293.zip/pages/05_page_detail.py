import streamlit as st
from modules.data_store import DataStore
from modules.page_generator import PageGenerator
from modules.ai_provider import AIProvider
from modules.prompt_manager import PromptManager
from modules.settings_manager import SettingsManager
from modules.chat_manager import ChatManager

def render_page_detail_page():
    '''ページ詳細ページのメイン関数'''
    st.title('📝 ページ詳細')
    
    # 初期化
    if 'data_store' not in st.session_state:
        st.session_state.data_store = DataStore()
    
    data_store = st.session_state.data_store
    
    # 商品データを取得
    products = data_store.load_all_products()
    if not products:
        st.warning("商品データがありません。まず商品を作成してください。")
        return
    
    # 商品選択
    product_names = [p['name'] for p in products]
    selected_product_name = st.selectbox(
        "商品を選択",
        product_names,
        key="product_selector"
    )
    
    if not selected_product_name:
        return
    
    # 選択された商品を取得
    product = next((p for p in products if p['name'] == selected_product_name), None)
    if not product:
        st.error("商品が見つかりません。")
        return
    
    product_id = product['id']
    
    # サイト構成を取得
    structure = product.get('structure', {}).get('pages', [])
    if not structure:
        st.warning("サイト構成がありません。まずサイト構成を作成してください。")
        return
    
    # ページ選択
    selected_page = render_page_selector(structure)
    if not selected_page:
        return
    
    page_id = selected_page['id']
    
    # ページ詳細を取得または生成
    page_details = product.get('page_details', {})
    if page_id not in page_details:
        with st.spinner("ページ詳細を生成中..."):
            settings_manager = SettingsManager()

            settings = settings_manager.get_settings()

            ai_provider = AIProvider(settings)

            prompt_manager = PromptManager()

            page_generator = PageGenerator(ai_provider, prompt_manager)
            page_details[page_id] = page_generator.generate_page_detail(
                selected_page, product
            )
            product['page_details'] = page_details
            data_store.save_product(product)
    
    page_detail = page_details[page_id]
    
    # ページ項目を表示
    render_page_items(page_detail, data_store, product_id)
    
    # チャットセクション
    if 'chat_manager' not in st.session_state:
        settings_manager = SettingsManager()

        settings = settings_manager.get_settings()

        ai_provider = AIProvider(settings)
        st.session_state.chat_manager = ChatManager(ai_provider)
    
    render_chat_section(st.session_state.chat_manager, product)

def render_page_selector(structure):
    '''ページ選択ドロップダウン'''
    page_options = []
    for page in structure:
        page_options.append({
            'label': f"{page.get('name', 'Untitled')}",
            'value': page
        })
    
    if not page_options:
        st.warning("ページが見つかりません。")
        return None
    
    selected_index = st.selectbox(
        "ページを選択",
        range(len(page_options)),
        format_func=lambda x: page_options[x]['label'],
        key="page_detail_selector"
    )
    
    return page_options[selected_index]['value']

def render_page_items(page_detail, data_store, product_id):
    '''ページ項目一覧'''
    if not page_detail or 'items' not in page_detail:
        st.warning("ページ項目がありません。")
        return
    
    st.subheader("ページ項目")
    
    items = page_detail['items']
    updated = False
    
    for item_index, item in enumerate(items):
        with st.expander(f"📋 {item.get('name', f'項目{item_index+1}')}", expanded=True):
            item_updated = render_item_candidates(
                item, item_index, page_detail.get('id'), data_store, product_id
            )
            if item_updated:
                updated = True
    
    if updated:
        # 商品データを更新
        products = data_store.load_all_products()
        product = next((p for p in products if p['id'] == product_id), None)
        if product:
            data_store.save_product(product)

def render_item_candidates(item, item_index, page_id, data_store, product_id):
    '''項目候補表示'''
    candidates = item.get('candidates', [])
    if not candidates:
        st.warning("候補がありません。")
        return False
    
    # 候補選択
    candidate_labels = []
    for i, candidate in enumerate(candidates):
        label = f"候補{chr(65+i)}: {candidate.get('value', '')[:50]}..."
        candidate_labels.append(label)
    
    # 現在選択されている候補を取得
    selected_index = 0
    for i, candidate in enumerate(candidates):
        if candidate.get('selected', False):
            selected_index = i
            break
    
    new_selected_index = st.radio(
        "候補を選択",
        range(len(candidates)),
        index=selected_index,
        format_func=lambda x: candidate_labels[x],
        key=f"candidate_{page_id}_{item_index}"
    )
    
    # 選択が変更された場合
    updated = False
    if new_selected_index != selected_index:
        # 選択状態を更新
        for i, candidate in enumerate(candidates):
            candidate['selected'] = (i == new_selected_index)
        updated = True
    
    # 選択された候補のプレビュー
    selected_candidate = candidates[new_selected_index]
    st.markdown("**プレビュー:**")
    st.markdown(selected_candidate.get('value', ''))
    
    # 候補再生成ボタン
    col1, col2 = st.columns([1, 3])
    with col1:
        if st.button('候補を再生成', key=f"regen_{page_id}_{item_index}"):
            settings_manager = SettingsManager()

            settings = settings_manager.get_settings()

            ai_provider = AIProvider(settings)

            prompt_manager = PromptManager()

            page_generator = PageGenerator(ai_provider, prompt_manager)
            new_candidates = regenerate_candidates(page_generator, item, page_id)
            if new_candidates:
                item['candidates'] = new_candidates
                updated = True
                st.success("候補を再生成しました。")
                st.rerun()
    
    return updated

def regenerate_candidates(page_generator, item, page_id):
    '''候補再生成'''
    try:
        # 新しい候補を生成
        new_candidates = []
        for i in range(3):  # A, B, C の3つの候補
            candidate_value = page_generator.generate_item_candidate(item)
            new_candidates.append({
                'value': candidate_value,
                'selected': i == 0  # 最初の候補を選択状態にする
            })
        
        return new_candidates
    except Exception as e:
        st.error(f"候補の再生成に失敗しました: {str(e)}")
        return None

def render_chat_section(chat_manager, product_data):
    '''チャットセクション'''
    st.subheader("💬 AIチャット")
    st.write("ページの内容について質問や修正指示ができます。")
    
    # チャット履歴表示
    if 'page_detail_chat_history' not in st.session_state:
        st.session_state.page_detail_chat_history = []
    
    chat_history = st.session_state.page_detail_chat_history
    
    # チャット履歴を表示
    for message in chat_history:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    
    # チャット入力
    user_input = st.chat_input("質問や修正指示を入力してください...")
    
    if user_input:
        # ユーザーメッセージを追加
        chat_history.append({"role": "user", "content": user_input})
        
        with st.chat_message("user"):
            st.markdown(user_input)
        
        # AI応答を生成
        with st.chat_message("assistant"):
            with st.spinner("AI が回答を生成中..."):
                try:
                    context = f"商品名: {product_data.get('name', '')}\n"
                    context += f"商品説明: {product_data.get('description', '')}"
                    
                    response = chat_manager.get_response(
                        user_input,
                        context=context,
                        conversation_type="page_detail"
                    )
                    
                    st.markdown(response)
                    chat_history.append({"role": "assistant", "content": response})
                    
                except Exception as e:
                    error_msg = f"申し訳ございません。エラーが発生しました: {str(e)}"
                    st.error(error_msg)
                    chat_history.append({"role": "assistant", "content": error_msg})
        
        st.session_state.page_detail_chat_history = chat_history
        st.rerun()

render_page_detail_page()