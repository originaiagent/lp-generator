import streamlit as st

# ページタイトル設定（サイドバー表示用）
st.set_page_config(page_title="📋 製品一覧")

st.title("📋 製品一覧")

# 以下、既存のコード