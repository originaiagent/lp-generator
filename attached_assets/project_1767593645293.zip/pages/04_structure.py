import streamlit as st
from modules.data_store import DataStore

def render_structure_page():
    '''全体構成ページのメイン関数'''
    st.title('🏗️ 全体構成')
    
    data_store = DataStore()
    
    # 現在の商品IDを取得
    if 'current_product_id' not in st.session_state:
        st.warning("商品が選択されていません。入力画面から商品を選択してください。")
        return
    
    product_id = st.session_state.current_product_id
    product = data_store.get_product(product_id)
    
    if not product:
        st.error("商品データが見つかりません。")
        return
    
    # 参考画像から構成を分析ボタン
    col1, col2 = st.columns([2, 1])
    with col1:
        if st.button("📊 参考画像から構成を分析", type="primary"):
            with st.spinner("構成を分析中..."):
                # 分析処理をシミュレート
                st.success("構成の分析が完了しました。")
                st.rerun()
    
    # 構成データの取得
    structure = product.get('structure', {})
    pages = structure.get('pages', [])
    
    if not pages:
        # デフォルトの構成を作成
        default_pages = [
            {
                'id': 'first_view',
                'order': 1,
                'type': 'first_view',
                'title': 'ファーストビュー',
                'summary': '訪問者の注意を引く最初の画面',
                'elements': ['メインビジュアル', 'キャッチコピー', 'CTAボタン']
            },
            {
                'id': 'comparison',
                'order': 2,
                'type': 'comparison',
                'title': '比較表',
                'summary': '商品・サービスの比較情報',
                'elements': ['比較表', '特徴説明', '価格比較']
            },
            {
                'id': 'features',
                'order': 3,
                'type': 'features',
                'title': '特徴・機能',
                'summary': '商品の特徴や機能の詳細説明',
                'elements': ['機能一覧', '詳細説明', '画像・動画']
            }
        ]
        
        # デフォルト構成を保存
        if 'structure' not in product:
            product['structure'] = {}
        product['structure']['pages'] = default_pages
        data_store.update_product(product_id, product)
        pages = default_pages
    
    # ページリストの表示
    render_page_list(structure, data_store, product_id)

def render_page_list(structure, data_store, product_id):
    '''ページリスト表示'''
    product = data_store.get_product(product_id)
    pages = product.get('structure', {}).get('pages', [])
    
    if not pages:
        st.info("構成が設定されていません。")
        return
    
    # ページの順序でソート
    pages_sorted = sorted(pages, key=lambda x: x.get('order', 0))
    
    st.subheader("📄 ページ構成")
    
    for index, page in enumerate(pages_sorted):
        render_page_item(page, index, data_store, product_id)

def render_page_item(page, index, data_store, product_id):
    '''単一ページ項目'''
    page_order = page.get('order', index + 1)
    page_title = page.get('title', 'タイトル未設定')
    page_summary = page.get('summary', '概要未設定')
    page_elements = page.get('elements', [])
    
    # expander で折り畳み表示
    with st.expander(f"P{page_order} - {page_title}", expanded=False):
        col1, col2 = st.columns([3, 1])
        
        with col1:
            st.write(f"**概要:** {page_summary}")
            
            if page_elements:
                st.write("**構成要素:**")
                for element in page_elements:
                    st.write(f"• {element}")
            else:
                st.write("構成要素が設定されていません。")
        
        with col2:
            # 編集ボタン
            edit_key = f"edit_{page.get('id', index)}"
            if st.button("✏️ 編集", key=edit_key):
                edit_page(page.get('id', index), data_store, product_id)
            
            # 上下移動ボタン
            move_up_key = f"move_up_{page.get('id', index)}"
            move_down_key = f"move_down_{page.get('id', index)}"
            
            if page_order > 1:
                if st.button("⬆️", key=move_up_key, help="上に移動"):
                    update_page_order_up(page, data_store, product_id)
            
            product = data_store.get_product(product_id)
            pages = product.get('structure', {}).get('pages', [])
            if page_order < len(pages):
                if st.button("⬇️", key=move_down_key, help="下に移動"):
                    update_page_order_down(page, data_store, product_id)

def update_page_order(pages, data_store, product_id):
    '''ページ順序更新'''
    product = data_store.get_product(product_id)
    if product:
        product['structure']['pages'] = pages
        data_store.update_product(product_id, product)
        st.rerun()

def update_page_order_up(page, data_store, product_id):
    '''ページを上に移動'''
    product = data_store.get_product(product_id)
    pages = product.get('structure', {}).get('pages', [])
    
    current_order = page.get('order', 0)
    if current_order > 1:
        # 現在のページの順序を上げる
        for p in pages:
            if p.get('id') == page.get('id'):
                p['order'] = current_order - 1
            elif p.get('order') == current_order - 1:
                p['order'] = current_order
        
        product['structure']['pages'] = pages
        data_store.update_product(product_id, product)
        st.rerun()

def update_page_order_down(page, data_store, product_id):
    '''ページを下に移動'''
    product = data_store.get_product(product_id)
    pages = product.get('structure', {}).get('pages', [])
    
    current_order = page.get('order', 0)
    max_order = len(pages)
    
    if current_order < max_order:
        # 現在のページの順序を下げる
        for p in pages:
            if p.get('id') == page.get('id'):
                p['order'] = current_order + 1
            elif p.get('order') == current_order + 1:
                p['order'] = current_order
        
        product['structure']['pages'] = pages
        data_store.update_product(product_id, product)
        st.rerun()

def edit_page(page_id, data_store, product_id):
    '''ページ編集'''
    product = data_store.get_product(product_id)
    pages = product.get('structure', {}).get('pages', [])
    
    # 編集対象のページを取得
    target_page = None
    for page in pages:
        if page.get('id') == page_id:
            target_page = page
            break
    
    if not target_page:
        st.error("編集対象のページが見つかりません。")
        return
    
    # 編集フォーム
    st.subheader(f"✏️ ページ編集: {target_page.get('title', '')}")
    
    with st.form(f"edit_form_{page_id}"):
        new_title = st.text_input("タイトル", value=target_page.get('title', ''))
        new_summary = st.text_area("概要", value=target_page.get('summary', ''))
        
        # 構成要素の編集
        elements = target_page.get('elements', [])
        elements_text = '\n'.join(elements)
        new_elements_text = st.text_area("構成要素（1行に1つずつ）", value=elements_text)
        
        col1, col2 = st.columns(2)
        with col1:
            if st.form_submit_button("💾 保存", type="primary"):
                # 更新処理
                target_page['title'] = new_title
                target_page['summary'] = new_summary
                target_page['elements'] = [elem.strip() for elem in new_elements_text.split('\n') if elem.strip()]
                
                data_store.update_product(product_id, product)
                st.success("ページが更新されました。")
                st.rerun()
        
        with col2:
            if st.form_submit_button("❌ キャンセル"):
                st.rerun()

# メイン関数を呼び出し
render_structure_page()