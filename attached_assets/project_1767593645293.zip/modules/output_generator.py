from typing import Dict

class OutputGenerator:
    def __init__(self, ai_provider, prompt_manager):
        self.ai_provider = ai_provider
        self.prompt_manager = prompt_manager

    def build_image_prompt(self, page_detail: Dict, tone_analysis: Dict) -> str:
        prompt_parts = []
        
        # トーンとスタイル情報を追加
        if 'style' in tone_analysis:
            prompt_parts.append(f"Style: {tone_analysis['style']}")
        
        if 'colors' in tone_analysis:
            colors = ', '.join(tone_analysis['colors'])
            prompt_parts.append(f"Colors: {colors}")
        
        # ページの詳細情報を追加
        if 'items' in page_detail:
            for item in page_detail['items']:
                if 'candidates' in item:
                    for candidate in item['candidates']:
                        if candidate.get('selected', False):
                            prompt_parts.append(f"{item['name']}: {candidate['value']}")
        
        return ' | '.join(prompt_parts) if prompt_parts else "Design image"

    def generate_design_instruction(self, product_data: Dict) -> str:
        instruction_parts = []
        
        # 製品名を含める
        if 'name' in product_data:
            instruction_parts.append(f"Product: {product_data['name']}")
        
        # ページ詳細情報を処理
        if 'page_details' in product_data:
            for page in product_data['page_details']:
                if 'items' in page:
                    for item in page['items']:
                        if 'candidates' in item:
                            for candidate in item['candidates']:
                                if candidate.get('selected', False):
                                    instruction_parts.append(f"{item['name']}: {candidate['value']}")
        
        return '\n'.join(instruction_parts) if instruction_parts else f"Design instruction for {product_data.get('name', 'product')}"