from typing import List, Dict, Any

class ImageAnalyzer:
    def __init__(self, ai_provider, prompt_manager):
        self.ai_provider = ai_provider
        self.prompt_manager = prompt_manager
    
    def analyze_references(self, image_paths: List[str]) -> Dict[str, Any]:
        try:
            # AIを使用した分析を試行
            if hasattr(self.ai_provider, 'analyze_images') and callable(getattr(self.ai_provider, 'analyze_images')):
                result = self.ai_provider.analyze_images(image_paths)
                if isinstance(result, dict) and "pages" in result:
                    return result
        except:
            pass
        
        # AIが使えない場合やエラーの場合はモックデータを返す
        return {
            "pages": [
                {
                    "page_number": i + 1,
                    "elements": ["text", "image", "layout"],
                    "structure": "standard"
                } for i in range(len(image_paths))
            ]
        }
    
    def analyze_tone_manner(self, image_paths: List[str]) -> Dict[str, Any]:
        try:
            # AIを使用した分析を試行
            if hasattr(self.ai_provider, 'analyze_tone') and callable(getattr(self.ai_provider, 'analyze_tone')):
                result = self.ai_provider.analyze_tone(image_paths)
                if isinstance(result, dict):
                    return result
        except:
            pass
        
        # AIが使えない場合やエラーの場合はモックデータを返す
        return {
            "tone": "professional",
            "manner": "formal",
            "style": "clean"
        }