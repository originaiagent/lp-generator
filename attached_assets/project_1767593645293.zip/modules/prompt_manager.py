import json
import os
from typing import Dict, List

class PromptManager:
    DEFAULT_PROMPTS = {
        "image_analysis": "この画像を分析してください。製品名: {product_name}",
        "general_analysis": "以下の内容について分析してください: {content}",
        "summary": "{text}を要約してください。"
    }
    
    def __init__(self, prompts_file: str = "prompts/default_prompts.json"):
        self.prompts_file = prompts_file
        self._ensure_prompts_directory()
        self._load_or_create_prompts()
    
    def _ensure_prompts_directory(self):
        """promptsディレクトリが存在しない場合は作成する"""
        dir_path = os.path.dirname(self.prompts_file)
        if dir_path:  # ディレクトリパスが空でない場合のみ作成
            os.makedirs(dir_path, exist_ok=True)
    
    def _load_or_create_prompts(self):
        """プロンプトファイルを読み込むか、存在しない場合は作成する"""
        try:
            if os.path.exists(self.prompts_file):
                with open(self.prompts_file, 'r', encoding='utf-8') as f:
                    loaded_prompts = json.load(f)
                    # 読み込んだプロンプトが空でないことを確認
                    if loaded_prompts:
                        self.prompts = loaded_prompts
                    else:
                        self.prompts = self.DEFAULT_PROMPTS.copy()
                        self._save_prompts()
            else:
                self.prompts = self.DEFAULT_PROMPTS.copy()
                self._save_prompts()
        except (json.JSONDecodeError, IOError):
            # ファイルが破損している場合はデフォルトを使用
            self.prompts = self.DEFAULT_PROMPTS.copy()
            self._save_prompts()
    
    def _save_prompts(self):
        """プロンプトをファイルに保存する"""
        try:
            with open(self.prompts_file, 'w', encoding='utf-8') as f:
                json.dump(self.prompts, f, ensure_ascii=False, indent=2)
        except IOError:
            pass  # ファイル保存に失敗しても継続
    
    def get_prompt(self, prompt_id: str, variables: Dict[str, str] = None) -> str:
        """プロンプトを取得し、変数があれば埋め込む"""
        if prompt_id not in self.prompts:
            return ""
        
        template = self.prompts[prompt_id]
        if variables:
            try:
                return template.format(**variables)
            except KeyError:
                # 変数が不足している場合は元のテンプレートを返す
                return template
        return template
    
    def list_prompts(self) -> List[str]:
        """プロンプトIDの一覧を返す"""
        return list(self.prompts.keys())
    
    def update_prompt(self, prompt_id: str, template: str) -> bool:
        """プロンプトを更新する"""
        self.prompts[prompt_id] = template
        self._save_prompts()
        return True
    
    def reset_to_default(self, prompt_id: str) -> bool:
        """プロンプトをデフォルトに戻す"""
        if prompt_id in self.DEFAULT_PROMPTS:
            self.prompts[prompt_id] = self.DEFAULT_PROMPTS[prompt_id]
            self._save_prompts()
            return True
        return False