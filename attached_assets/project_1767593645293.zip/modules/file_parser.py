import pandas as pd
import os
from typing import Dict, Any

class FileParser:
    
    def __init__(self):
        pass
    
    def parse(self, file_path: str) -> Dict[str, Any]:
        filename = os.path.basename(file_path)
        
        if file_path.endswith('.csv'):
            df = pd.read_csv(file_path)
            content = df.to_dict('records')
            
            return {
                "type": "csv",
                "content": content,
                "metadata": {
                    "filename": filename
                }
            }
    
    def extract_product_info(self, parsed_data: Dict[str, Any]) -> Dict[str, Any]:
        return {}